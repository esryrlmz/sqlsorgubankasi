

  CREATE TABLE "SA"."SERVIS" 
   (	"SERVIS_ID" NUMBER(*,0) , 
	"SERVIS_ADI" VARCHAR2(100 BYTE), 
	"IS_DELETE" CHAR(1 BYTE) DEFAULT 0, 
	"CREATED_AT" DATE DEFAULT current_date
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into SA.SERVIS
SET DEFINE OFF;
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('1','Aile Planlaması Polikliniği','0',to_date('12/06/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('2','Aile Hekimliği','0',to_date('17/07/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('3','Anestezi Polikliniği','0',to_date('27/05/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('4','Aşı Merkezi','0',to_date('12/05/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('5','Beslenme Polikliniği','0',to_date('20/02/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('6','Beyin ve Sinir Cerrahisi Polikliniği','0',to_date('28/12/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('7','Büyük Enfeksiyon Hastalıkları Polikliniği','0',to_date('07/05/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('8','Böbrek Nakli Hazırlık Poliklinikleri','0',to_date('20/06/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('9','Cildiye Poliklinikleri','0',to_date('20/06/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('10','Sedef(Psoriasis) Polikliniği','0',to_date('20/11/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('11','Çocuk Cerrahi Hastalıkları Polikliniği','0',to_date('06/04/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('12','Çocuk Dahiliye Hastalıkları Poliklinikleri','0',to_date('24/04/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('13','Çocuk Diyabet Polikliniği','0',to_date('04/06/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('14','Çocuk Allerji ve İmmünoloji','0',to_date('10/12/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('15','Çocuk Endokrin Poliklinikleri','0',to_date('24/01/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('16','Çocuk Enfeksiyon Hastalıkları Polikliniği','0',to_date('04/06/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('17','Çocuk Göğüs Hastalıkları','0',to_date('14/11/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('18','Çocuk Gastroenteroloji Polikliniği','0',to_date('28/07/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('19','Çocuk Hematolojisi Polikliniği','0',to_date('30/03/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('20','Çocuk Nefroloji Polikliniği','0',to_date('05/04/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('21','Çocuk Nörolojisi Polikilniği','0',to_date('27/08/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('22','Çocuk Onkolojisi Polikliniği','0',to_date('30/05/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('23','Çocuk Psikiyatri Polikliniği','0',to_date('23/07/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('24','Dahiliye Poliklinikleri','0',to_date('19/05/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('25','Diyabet Eğitim Polikliniği','0',to_date('10/11/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('26','Diyabet Poliklinikleri','0',to_date('27/01/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('27','Diş Poliklinikleri','0',to_date('10/02/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('28','Endokrinoloji Polikliniği','0',to_date('10/10/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('29','El Cerrahisi','0',to_date('06/09/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('30','Fizik Tedavi ve Rehabilitasyon Poliklinikleri','0',to_date('01/10/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('31','Romatoloji','0',to_date('14/12/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('32','Çocuk Omuz','0',to_date('25/03/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('33','Osteoporoz','0',to_date('04/12/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('34','Gastroenteroloji Poliklinikleri','0',to_date('02/03/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('35','Genel Cerrahi Poliklinikleri','0',to_date('27/07/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('36','Göğüs Hastalıkları ve Tbc. Polikliniği','0',to_date('05/07/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('37','Göğüs Cerrahi Poliklinikleri','0',to_date('24/04/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('38','Göz Poliklinikleri','0',to_date('04/08/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('39','Hematoloji Poliklinikleri','0',to_date('02/02/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('40','Hemodiyaliz Polikliniği','0',to_date('13/09/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('41','Kalp Damar Cerrahi Poliklinikleri','0',to_date('24/01/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('42','Kadın Doğum Poliklinikleri','0',to_date('21/12/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('43','Jinekolojik Onkoloji','0',to_date('03/03/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('44','Kardiyoloji Poliklinikleri','0',to_date('12/09/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('45','Kulak Burun Boğaz  Poliklinikleri','0',to_date('15/04/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('46','Horlama Polikliniği','0',to_date('03/02/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('47','Medikal Onkoloji Polikliniği','0',to_date('23/10/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('48','Meme Polikliniği','0',to_date('05/09/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('49','Nefroloji Poliklinikleri','0',to_date('12/07/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('50','Nöroloji Poliklinikleri','0',to_date('12/06/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('51','SVA Polikliniği','0',to_date('29/06/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('52','Epilepsi','0',to_date('21/03/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('53','Parkinson','0',to_date('08/04/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('54','MS Polikliniği','0',to_date('11/01/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('55','Doppler','0',to_date('06/02/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('56','Serobrovasküler','0',to_date('20/11/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('57','Nükleer Tıp Polikliniği','0',to_date('04/10/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('58','Ortopedi Poliklinikleri','0',to_date('26/04/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('59','Organ Nakli Poliklinikleri','0',to_date('17/12/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('60','Perinatoloji Poliklinikleri','0',to_date('29/03/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('61','Periton Diyaliz Poliklinikleri','0',to_date('24/11/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('62','Psikiyatri Poliklinikleri','0',to_date('04/02/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('63','Plastik Cerrahi Poliklinikleri','0',to_date('15/12/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('64','Radyasyon Onkoloji Poliklinikleri','0',to_date('22/12/2021','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('65','Sigara Bırakma Poliklinikleri','0',to_date('06/07/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('66','Tıbbi Genetik Polikliniği','0',to_date('28/03/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('67','Tıbbi Onkoloji Poliklinikleri','0',to_date('08/04/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('68','Üroloji Poliklinikleri','0',to_date('31/07/2022','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('69','Yenidoğan Poliklinikleri','0',to_date('01/05/2019','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('70','Yanık Polikliniği (Çocuk)','0',to_date('03/04/2020','DD/MM/RRRR'));
Insert into SA.SERVIS (SERVIS_ID,SERVIS_ADI,IS_DELETE,CREATED_AT) values ('71','Psikodermatoloji Polikliniği','0',to_date('12/10/2019','DD/MM/RRRR'));
--------------------------------------------------------
--  DDL for Index SERVIS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SA"."SERVIS_PK" ON "SA"."SERVIS" ("SERVIS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table SERVIS
--------------------------------------------------------

  ALTER TABLE "SA"."SERVIS" MODIFY ("SERVIS_ID" NOT NULL ENABLE);
  ALTER TABLE "SA"."SERVIS" ADD CHECK (is_delete=0 or is_delete=1) ENABLE;
  ALTER TABLE "SA"."SERVIS" ADD CONSTRAINT "SERVIS_PK" PRIMARY KEY ("SERVIS_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;

  create sequence seq_servis start with 72;
alter table servis modify(servis_id default seq_servis.nextval);